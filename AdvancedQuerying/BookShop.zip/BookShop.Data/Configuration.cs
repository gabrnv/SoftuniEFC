﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-J11J82N\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
