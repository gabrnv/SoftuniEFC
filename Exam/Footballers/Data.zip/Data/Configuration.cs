﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-J11J82N\SQLEXPRESS;Database=Footballers;Trusted_Connection=True";
    }
}
